NUTMEG KOSHER MARKET - Netlify Package (v2, with Admin Dashboard)
================================================================

YOUR SITE IS ALREADY LIVE:  https://centerfresh13.netlify.app
This ZIP is an UPDATED version that adds:
  - An admin dashboard at /admin  (see all your orders in a table)
  - A fix for order storage (Netlify Blobs)

WHAT'S IN THIS ZIP
------------------
  index.html                        <- your store (2,436 products, real logo, cart, checkout)
  admin.html                        <- NEW: order dashboard (open at /admin)
  netlify.toml                      <- routing (maps /api/* and /admin)
  package.json                      <- dependency (@netlify/blobs)
  netlify/functions/products.js     <- serves the catalog
  netlify/functions/departments.js  <- serves the 18 departments
  netlify/functions/orders.js       <- saves each order
  netlify/functions/get-orders.js   <- lists saved orders (used by /admin)

HOW TO UPDATE YOUR LIVE SITE
----------------------------
1. UNZIP this file.
2. Go to https://app.netlify.com  and open your existing site (centerfresh13).
3. Go to the "Deploys" tab and drag the UNZIPPED FOLDER onto the deploy area
   (this replaces the current version).
   -- OR just use https://app.netlify.com/drop again for a fresh site.

ENABLING ORDER STORAGE (one-time)
---------------------------------
Order saving uses "Netlify Blobs". If /admin shows a Blobs error:
  1. In your Netlify site dashboard, deploy this package (it lists @netlify/blobs
     in package.json, so Netlify installs it during the build).
  2. Blobs auto-enables for sites deployed with a package.json present.
If it still errors, the admin page will tell you exactly what it needs.

USING THE DASHBOARD
-------------------
  Store (customers):  https://YOUR-SITE.netlify.app
  Admin (you):        https://YOUR-SITE.netlify.app/admin
The dashboard shows total orders, revenue, items sold, and every order.

CARD PAYMENTS (later)
---------------------
To charge real cards, create a Stripe account and add your own Stripe keys
as environment variables in Netlify. Never hard-code keys into these files.

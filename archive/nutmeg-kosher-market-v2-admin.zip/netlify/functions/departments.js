const DEPARTMENTS = [{"name":"Breakfast Bar","count":67},{"name":"Household","count":36},{"name":"Groceries","count":383},{"name":"Dairy & Eggs","count":13},{"name":"Produce","count":214},{"name":"Frozen","count":64},{"name":"Fresh Meat","count":154},{"name":"Beverages","count":319},{"name":"Fish","count":94},{"name":"Candy & Sweets","count":168},{"name":"Fresh Bakery","count":49},{"name":"Catering","count":15},{"name":"Provisions","count":444},{"name":"Deli","count":216},{"name":"Baby Care","count":18},{"name":"Sushi","count":47},{"name":"Beauty & Personal","count":110},{"name":"Media","count":25}];
exports.handler = async () => ({
  statusCode: 200,
  headers: { 'Content-Type':'application/json','Access-Control-Allow-Origin':'*' },
  body: JSON.stringify(DEPARTMENTS)
});

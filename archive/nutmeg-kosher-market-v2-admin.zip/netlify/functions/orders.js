// Accepts a new order and saves it to Netlify Blobs storage.
// Configures Blobs manually so it works even on drag-and-drop deploys.
const { getStore } = require('@netlify/blobs');

function ordersStore() {
  const siteID = process.env.NETLIFY_SITE_ID || process.env.SITE_ID;
  const token  = process.env.NETLIFY_API_TOKEN || process.env.NETLIFY_BLOBS_TOKEN;
  if (siteID && token) {
    return getStore({ name: 'orders', siteID, token });
  }
  // Fall back to auto-config (works on normal Netlify builds)
  return getStore('orders');
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }
  try {
    const order = JSON.parse(event.body || '{}');
    const store = ordersStore();
    const id = Date.now().toString();
    const record = {
      id,
      items: order.items || [],
      total: order.total || 0,
      customer: order.customer || null,
      createdAt: new Date().toISOString()
    };
    await store.setJSON(id, record);
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ ok: true, orderId: id, total: record.total })
    };
  } catch (e) {
    return { statusCode: 500, headers: {'Access-Control-Allow-Origin':'*'}, body: JSON.stringify({ error: e.message }) };
  }
};

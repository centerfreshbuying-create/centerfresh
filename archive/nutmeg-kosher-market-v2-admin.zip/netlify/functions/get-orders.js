// Returns all saved orders from Netlify Blobs storage.
const { getStore } = require('@netlify/blobs');

function ordersStore() {
  const siteID = process.env.NETLIFY_SITE_ID || process.env.SITE_ID;
  const token  = process.env.NETLIFY_API_TOKEN || process.env.NETLIFY_BLOBS_TOKEN;
  if (siteID && token) {
    return getStore({ name: 'orders', siteID, token });
  }
  return getStore('orders');
}

exports.handler = async () => {
  try {
    const store = ordersStore();
    const { blobs } = await store.list();
    const orders = [];
    for (const b of blobs) {
      const o = await store.get(b.key, { type: 'json' });
      if (o) orders.push(o);
    }
    orders.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify(orders)
    };
  } catch (e) {
    return { statusCode: 500, headers: {'Access-Control-Allow-Origin':'*'}, body: JSON.stringify({ error: e.message }) };
  }
};
